import fs from 'node:fs';
import assert from 'node:assert/strict';
const videos=JSON.parse(fs.readFileSync('content/videos.json','utf8'));
assert.equal(new Set(videos.map(v=>v.id)).size,videos.length,'Video IDs must be unique');
for(const lang of ['','fa/']) {
 const html=fs.readFileSync(`docs/${lang}videos/index.html`,'utf8');
 assert.equal((html.match(/data-youtube=/g)||[]).length,videos.length);
 assert.ok(!html.includes('<iframe'),'No YouTube player should load before a click');
 assert.ok(html.includes('frame-src https://www.youtube-nocookie.com;'));
 assert.ok(html.includes("object-src 'none'"));
 for(const v of videos) {
  assert.match(v.id,/^[A-Za-z0-9_-]{11}$/);
  assert.ok(html.includes(`data-youtube="${v.id}"`));
  assert.ok(html.includes(v.format==='short'?`https://www.youtube.com/shorts/${v.id}`:`https://www.youtube.com/watch?v=${v.id}`));
 }
 for(const slug of ['silk-road-airport','neighbourhood-center','animation']) {
  const project=fs.readFileSync(`docs/${lang}projects/${slug}/index.html`,'utf8');
  assert.ok(project.includes('data-youtube='),`${slug} must include embedded video cards`);
 }
}
console.log(`PASS: ${videos.length} unique videos, bilingual cards, click-to-load players, fallback links and project integration.`);
