// Titles and IDs verified on the public CompassVision channel, 2026-10-11.
export function videoCards(videos,{t,esc}) {
  return videos.map(v=>{
    if(!/^[A-Za-z0-9_-]{11}$/.test(v.id)) throw new Error('Invalid YouTube video ID');
    const url=v.format==='short'?`https://www.youtube.com/shorts/${v.id}`:`https://www.youtube.com/watch?v=${v.id}`;
    return `<article class="video-card ${v.format==='short'?'video-card-short':''}" data-video-card>
      <div class="video-frame" data-video-frame>
        <button class="video-launch" data-youtube="${v.id}" data-video-title="${esc(v.title)}" aria-label="${esc(t('Play: ','پخش: ')+v.title)}">
          <img src="https://i.ytimg.com/vi/${v.id}/hqdefault.jpg" alt="" width="480" height="360" loading="lazy" decoding="async">
          <span class="video-play" aria-hidden="true">▶</span><span class="video-launch-label">${t('Play video','پخش ویدئو')}</span>
        </button>
      </div>
      <div class="video-info"><span class="eyebrow">${v.format==='short'?'YouTube Shorts':'Compass Vision'}</span><h3 dir="auto">${esc(v.title)}</h3>
      <div class="video-actions"><a href="${url}" target="_blank" rel="noopener noreferrer">${t('Watch on YouTube','تماشا در یوتیوب')} ↗</a><button data-video-stop hidden>${t('Close player','بستن پخش‌کننده')} ×</button></div></div>
    </article>`;
  }).join('');
}
export function videoSection(videos,ctx) {
  const {t}=ctx;
  return `<section class="section video-section" id="films"><div class="section-head"><div><span class="eyebrow">Compass Vision</span><h2>${t('Watch the work.','تماشای آثار.')}</h2></div></div><div class="video-grid">${videoCards(videos,ctx)}</div></section>`;
}
export function videosPage(videos,ctx) {
  const {t,head}=ctx;
  return head(t('Motion & films.','موشن و ویدئو.'),t('Architectural films and short visual explorations from Compass Vision.','فیلم‌های معماری و تجربه‌های کوتاه تصویری از کانال چشم‌انداز پرگار.'))+
    `<section class="section video-intro"><a class="text-link" href="https://www.youtube.com/@CompassVision" target="_blank" rel="noopener noreferrer">${t('Explore Compass Vision','کانال چشم‌انداز پرگار')} ↗</a><p class="muted">${t('Choose a video to load the YouTube player. YouTube access is required; if playback is unavailable, use the direct link.','با انتخاب ویدئو، پخش‌کنندهٔ یوتیوب بارگذاری می‌شود. پخش نیازمند دسترسی به یوتیوب است؛ اگر پخش در دسترس نبود، از لینک مستقیم استفاده کنید.')}</p><nav class="video-jumps" aria-label="${t('Video collections','مجموعه‌های ویدئو')}"><a class="pill" href="#films">${t('Films · 4','ویدئوها · ۴')}</a><a class="pill" href="#shorts">${t('Shorts · 7','شرت‌ها · ۷')}</a></nav></section>`+
    videoSection(videos.filter(v=>v.format==='video'),ctx)+
    `<section class="section video-section" id="shorts"><div class="section-head"><div><span class="eyebrow">YouTube Shorts</span><h2>${t('Short-form explorations.','تجربه‌های کوتاه.')}</h2></div></div><div class="video-grid video-grid-shorts">${videoCards(videos.filter(v=>v.format==='short'),ctx)}</div></section>`;
}
