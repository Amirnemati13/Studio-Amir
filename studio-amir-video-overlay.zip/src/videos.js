'use strict';
// Create a player only following a user action, and allow just one at a time.
(() => {
  let active = null;
  function closePlayer(restoreFocus = false) {
    if (!active) return;
    const {button, frame, stop} = active;
    frame.querySelector('iframe')?.remove();
    button.hidden = false;
    stop.hidden = true;
    if (restoreFocus) button.focus();
    active = null;
  }
  document.querySelectorAll('[data-youtube]').forEach(button => {
    button.addEventListener('click', () => {
      const id = button.dataset.youtube;
      if (!/^[A-Za-z0-9_-]{11}$/.test(id)) return;
      closePlayer();
      const card = button.closest('[data-video-card]');
      const frame = card.querySelector('[data-video-frame]');
      const stop = card.querySelector('[data-video-stop]');
      const player = document.createElement('iframe');
      player.title = button.dataset.videoTitle;
      player.src = `https://www.youtube-nocookie.com/embed/${id}?autoplay=1&playsinline=1&rel=0`;
      player.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
      player.allowFullscreen = true;
      player.referrerPolicy = 'strict-origin-when-cross-origin';
      button.hidden = true;
      stop.hidden = false;
      frame.appendChild(player);
      active = {button, frame, stop};
      player.focus();
    });
  });
  document.querySelectorAll('[data-video-stop]').forEach(button => button.addEventListener('click', () => closePlayer(true)));
  // Escape works when focus is in the host page. Inside YouTube, use its controls.
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && active) closePlayer(true); });
})();
