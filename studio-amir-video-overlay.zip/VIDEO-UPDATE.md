# Compass Vision video update — 2026-10-11

This is the updated, independent local copy of Studio Amir. The original local project and the live GitHub Pages site were not changed.

## Included
- 11 public videos verified on https://www.youtube.com/@CompassVision: 4 regular videos and 7 Shorts.
- English /videos/ and Persian /fa/videos/, linked from navigation and homepage.
- Embedded video cards on the existing airport and motion studies pages, plus Neighborhood Center.
- Responsive 16:9 / 9:16 frames, click-to-load privacy-enhanced YouTube embeds, one active player at a time, explicit close button and direct YouTube links.
- CSP permits only YouTube's privacy-enhanced frame host and YouTube thumbnails; other existing restrictions remain.
- Original YouTube titles preserved. New uploads are not synchronized automatically; edit content/videos.json and rebuild.

## Preview and checks
Run npm run build, npm run check, node scripts/check-videos.mjs, then npm run preview from this folder. Use HTTP preview, not file://, for reliable YouTube playback.

Validated: all 43 HTML files and internal references, unique video IDs, bilingual inclusion, fallback links, no initial iframe, desktop player, Shorts playback, single-player replacement, player close, Persian mobile layout at 390 px. Playback sampled on Grasshopper projects and Lili OrangeRhino; not every video or device was playback-tested.

## Publication
Not published. The adjacent studio-amir-video-overlay.zip contains updated source, content, checks and this note. It does not contain the full image archive. For the existing GitHub recovery workflow, extract this overlay AFTER all existing archive overlays, then run the build and both checks. Publish the resulting docs directory using the existing GitHub Pages workflow only after approval. Do not replace old archive checksums or publish just the overlay.
